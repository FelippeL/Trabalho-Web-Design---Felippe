<!DOCTYPE html>
    <head>
        <title>Início</title>
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="css/index.css" rel="stylesheet">
    </head>

    <body>
    <!DOCTYPE html>
<html>

    <body>

        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "db_bingo";

            try {
                $conn = new mysqli("localhost", "root", "");
            } catch (\Exception $e) {
                echo $e->getMessage(), PHP_EOL;
            }
            if ($conn->select_db('db_bingo') === false) {
                $conn->query("CREATE SCHEMA `db_bingo`;");
                $conn->query("CREATE TABLE `db_bingo`.`cartelas` (
                                    `id_cartelas` int(11) NOT NULL AUTO_INCREMENT,
                                    `no_valores` varchar(45) NOT NULL,
                                    `no_sorteio` varchar(45) NOT NULL,
                                    PRIMARY KEY (`id_cartelas`)
                                    ) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;");
            }
            session_start();
            $cartela = array();
            $cont = 0;
            while($cont < 3){
                $sorteado = rand(1, 20);
                $tamanho = count($cartela);
                $flag = 0;
                for($x = 0; $x < $tamanho; $x++) {
                    if($cartela[$x] == $sorteado){
                        $flag = 1;
                    }
                }
                if($flag == 0){
                    array_push($cartela, $sorteado);
                    $cont++;
                }
            }
            $cont = 0;
            while($cont < 3){
                $sorteado = rand(21,40);
                $tamanho = count($cartela);
                $flag = 0;
                for($x = 0; $x < $tamanho; $x++) {
                    if($cartela[$x] == $sorteado){
                        $flag = 1;
                    }
                }
                if($flag == 0){
                    array_push($cartela, $sorteado);
                    $cont++;
                }
            }
            $cont = 0;
            while($cont < 3){
                $sorteado = rand(41,60);
                $tamanho = count($cartela);
                $flag = 0;
                for($x = 0; $x < $tamanho; $x++) {
                    if($cartela[$x] == $sorteado){
                        $flag = 1;
                    }
                }
                if($flag == 0){
                    array_push($cartela, $sorteado);
                    $cont++;
                }
            }
            $_SESSION['cartela'] = $cartela;
            header("location:cartela.php");
            ?>

    <body>
</html>