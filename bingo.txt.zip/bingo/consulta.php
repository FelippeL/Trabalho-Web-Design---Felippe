<!DOCTYPE html>
    <head>
        <title>Constula</title>
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="css/consulta.css" rel="stylesheet">
    </head>

    <body>
    <!DOCTYPE html>
<html>

    <body>

        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "db_bingo";

            $conn = new mysqli($servername, $username, $password);

            $sql = "SELECT no_valores, no_sorteio FROM db_bingo.cartelas";
            $result = $conn->query($sql);
        ?>
        <div id='header' class='row'>
            <div class="topnav">
                <a href="index.php">Gerar Nova Cartela</a>
                <a href="cartela.php">Ver Cartela</a>
                <a href="sorteio.php">Sortear Números</a>
                <a href="gravar.php" class='disabled'>Gravar</a>
                <a href="consulta.php">Consultar</a>
            </div>
        </div>


        <div class='row'>
            <div id='content' class = 'col-lg-12 text-center'>
                <table>
                    <tr>
                        <th>Numeros da Cartela</th>
                        <th>Numeros Sorteados</th>
                    </tr>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            ?>
                            <tr>
                                <td><?php echo $row['no_valores']; ?></td>
                                <td><?php echo $row['no_sorteio']; ?></td>
                            </tr>
                        <?php }
                    }
                    ?>
                </table>
            </div>
        </div>
    <body>
</html>