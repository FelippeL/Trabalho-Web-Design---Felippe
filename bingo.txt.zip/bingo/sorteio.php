<!DOCTYPE html>
    <head>
        <title>Sorteio</title>
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="css/sorteio.css" rel="stylesheet">
    </head>

    <body>
    <!DOCTYPE html>
<html>

    <body>

        <?php
            session_start();
            $sorteio = array();
            $cont = 0;
            while($cont < 9){
                $tamanho = count($sorteio);
                $inserir = 1;
                $novo = rand(1,60);
                for($x = 0; $x < $tamanho; $x++){
                    if($sorteio[$x] == $novo){
                        $inserir = 0;
                    }
                }
                if($inserir == 1){
                    array_push($sorteio, $novo);
                    $cont++;
                }
            }
            $_SESSION['sorteio'] = $sorteio;
            $iguais = array();
            for($x = 0; $x < 9; $x++){
                $flag = 0;
                for($y = 0; $y < 9; $y++){
                    if($sorteio[$y] == $_SESSION['cartela'][$x]){
                        $flag = 1;
                    }
                }
                if($flag == 1){
                    array_push($iguais, 1);
                }
                else{
                    array_push($iguais, 0);
                }
            }
            $_SESSION['iguais'] = $iguais;
            function bgCor($pos){
                if($_SESSION['iguais'][$pos] == 1){
                    return 'green';
                }
                else{
                    return 'red';
                }
            }
        ?>
        <div id='header' class='row'>
            <div class="topnav">
                <a href="index.php">Gerar Nova Cartela</a>
                <a href="cartela.php">Ver Cartela</a>
                <a href="sorteio.php">Sortear Números</a>
                <a href="gravar.php">Gravar</a>
                <a href="consulta.php">Consultar</a>
            </div>
        </div>


        <div class='row'>
            <div id='content' class = 'col-lg-12 text-center'>
                <table>
                    <tr>
                        <td>Col1</td>
                        <td>Col2</td>
                        <td>Col3</td>
                    </tr>
                    <tr>
                        <td style = "background-color: <?php echo bgCor(0) ?>"><?php echo $_SESSION['cartela'][0]; ?></td>
                        <td style = "background-color: <?php echo bgCor(3) ?>"><?php echo $_SESSION['cartela'][3]; ?></td>
                        <td style = "background-color: <?php echo bgCor(6) ?>"><?php echo $_SESSION['cartela'][6]; ?></td>
                    </tr>
                    <tr>
                        <td style = "background-color: <?php echo bgCor(1) ?>"><?php echo $_SESSION['cartela'][1]; ?></td>
                        <td style = "background-color: <?php echo bgCor(4) ?>"><?php echo $_SESSION['cartela'][4]; ?></td>
                        <td style = "background-color: <?php echo bgCor(7) ?>"><?php echo $_SESSION['cartela'][7]; ?></td>
                    </tr>
                    <tr>
                        <td style = "background-color: <?php echo bgCor(2) ?>"><?php echo $_SESSION['cartela'][2]; ?></td>
                        <td style = "background-color: <?php echo bgCor(5) ?>"><?php echo $_SESSION['cartela'][5]; ?></td>
                        <td style = "background-color: <?php echo bgCor(8) ?>"><?php echo $_SESSION['cartela'][8]; ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class='row'>
            <div id='content' class = 'col-lg-12 text-center'>
                Sorteio = <?php for($x = 0; $x < 8; $x++){
                    echo $sorteio[$x].', ';
                }
                echo $sorteio[8];?>
            </div>
        </div>
    <body>
</html>