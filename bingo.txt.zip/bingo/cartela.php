<!DOCTYPE html>
    <head>
        <title>Cartela</title>
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="css/cartela.css" rel="stylesheet">
    </head>

    <body>
    <!DOCTYPE html>
<html>

    <body>
        <?php session_start(); ?>
        <div id='header' class='row'>
            <div class="topnav">
                <a href="index.php">Gerar Nova Cartela</a>
                <a href="cartela.php">Ver Cartela</a>
                <a href="sorteio.php">Sortear Números</a>
                <a href="gravar.php" class='disabled'>Gravar</a>
                <a href="consulta.php">Consultar</a>
            </div>
        </div>


        <div class='row'>
            <div id='content' class = 'col-lg-12 text-center'>
                <table>
                    <tr>
                        <td>Col1</td>
                        <td>Col2</td>
                        <td>Col3</td>
                    </tr>
                    <tr>
                        <td><?php echo $_SESSION['cartela'][0]; ?></td>
                        <td><?php echo $_SESSION['cartela'][3]; ?></td>
                        <td><?php echo $_SESSION['cartela'][6]; ?></td>
                    </tr>
                    <tr>
                        <td><?php echo $_SESSION['cartela'][1]; ?></td>
                        <td><?php echo $_SESSION['cartela'][4]; ?></td>
                        <td><?php echo $_SESSION['cartela'][7]; ?></td>
                    </tr>
                    <tr>
                        <td><?php echo $_SESSION['cartela'][2]; ?></td>
                        <td><?php echo $_SESSION['cartela'][5]; ?></td>
                        <td><?php echo $_SESSION['cartela'][8]; ?></td>
                    </tr>
                </table>
            </div>
        </div>
    <body>
</html>