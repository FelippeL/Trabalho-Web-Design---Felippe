<!DOCTYPE html>
    <head>
        <title>Gravação</title>
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="css/cartela.css" rel="stylesheet">
    </head>

    <body>
    <!DOCTYPE html>
<html>
    <body>

        <?php
        session_start();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "bd_bingo";

        $conn = new mysqli($servername, $username, $password);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
        $no_sorteio='';
        $no_valores='';
        for($x=0;$x<8;$x++){
            $no_valores .= $_SESSION['cartela'][$x] . ',';
        }
        $no_valores .= $_SESSION['cartela'][8];
        for($x=0;$x<8;$x++){
            $no_sorteio .= $_SESSION['sorteio'][$x] . ',';
        }
        $no_sorteio .= $_SESSION['sorteio'][8];

        $sql = "INSERT INTO `db_bingo`.`cartelas` (`no_valores`, `no_sorteio`) VALUES ('$no_valores', '$no_sorteio');";
        if ($conn->query($sql) === TRUE) {
            echo "<h1 style='text-align:center;'>Gravado! Redirecionando...</h1>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        sleep(2);

        header("refresh:3;url=cartela.php"); 
        ?>
    </body>
</html>